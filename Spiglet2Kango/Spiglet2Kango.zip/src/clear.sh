rm *.class
rm symbol/*.class
rm syntaxtree/*.class
rm visitor/*.class
