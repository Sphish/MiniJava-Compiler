rm *.class
rm printer/*.class
rm symbol/*.class
rm syntaxtree/*.class
rm visitor/*.class
